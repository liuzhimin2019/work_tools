
def main():
    print('This is my first package')

if __name__ == '__main__':
    main()
